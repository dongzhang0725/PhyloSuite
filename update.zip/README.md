# PhyloSuite
PhyloSuite is an integrated bionformatics platform designed to streamline evolutionary phylogenetics studies. It combines the functions of two previous tools: MitoTool (https://github.com/dongzhang0725/MitoTool) and BioSuite (https://github.com/dongzhang0725/BioSuite).
