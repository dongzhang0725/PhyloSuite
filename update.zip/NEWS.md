# Release Note

## PhyloSuite v1.1.3 (2018-09-29, Sat)
+ Rewrite the function of normalization
+ Optimize flowchart function
+ Optimize GenBank file display

## PhyloSuite v1.1.2 (2018-09-23, Sun)
+ fix some grammatical mistake 
+ trial version

