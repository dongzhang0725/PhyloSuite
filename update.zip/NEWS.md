# Release Note

## PhyloSuite v1.1.2 (2018-09-23, Sun)
+ fix some grammatical mistake 
+ trial version

